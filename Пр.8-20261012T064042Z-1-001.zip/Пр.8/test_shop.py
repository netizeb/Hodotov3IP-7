import os
import tempfile
import unittest

from shop import (
    get_low_stock,
    search_advanced,
    total_sum,
    cart_total,
    add_to_cart,
    remove_from_cart,
    update_quantity,
    count_by_category,
    load_orders,
    save_orders,
)


def make_products():
    """Свежий набор тестовых товаров для каждого теста."""
    return [
        {"id": 1, "name": "Футбольный мяч", "brand": "Adidas", "category": "Мячи", "price": 2500, "quantity": 10},
        {"id": 2, "name": "Баскетбольный мяч", "brand": "Nike", "category": "Мячи", "price": 3200, "quantity": 2},
        {"id": 3, "name": "Гантели 5 кг", "brand": "Torneo", "category": "Тренажёры", "price": 1800, "quantity": 3},
        {"id": 4, "name": "Беговые кроссовки", "brand": "Asics", "category": "Обувь", "price": 7500, "quantity": 6},
        {"id": 5, "name": "Скакалка", "brand": "Demix", "category": "Тренажёры", "price": 600, "quantity": 1},
    ]


# --- Задание 2: get_low_stock ---
class TestGetLowStock(unittest.TestCase):
    def test_empty_list(self):
        self.assertEqual(get_low_stock([]), [])

    def test_no_low_stock(self):
        products = [{"name": "A", "quantity": 10}]
        self.assertEqual(get_low_stock(products), [])

    def test_one_low_stock(self):
        products = [
            {"name": "A", "quantity": 1},
            {"name": "B", "quantity": 10},
        ]
        result = get_low_stock(products)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["name"], "A")

    def test_default_threshold_is_3(self):
        # остаток 3 попадает (<=), остаток 4 - уже нет
        products = [
            {"name": "A", "quantity": 3},
            {"name": "B", "quantity": 4},
        ]
        result = get_low_stock(products)
        self.assertEqual([p["name"] for p in result], ["A"])

    def test_sorted_by_quantity(self):
        result = get_low_stock(make_products())
        self.assertEqual([p["quantity"] for p in result], [1, 2, 3])


# --- Задание 2: search_advanced ---
class TestSearchAdvanced(unittest.TestCase):
    def setUp(self):
        self.products = make_products()

    def test_search_by_name(self):
        result = search_advanced(self.products, "гантели")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["id"], 3)

    def test_search_by_brand(self):
        result = search_advanced(self.products, "nike")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["id"], 2)

    def test_search_by_category(self):
        result = search_advanced(self.products, "", category="Мячи")
        self.assertEqual([p["id"] for p in result], [1, 2])

    def test_search_by_price(self):
        result = search_advanced(self.products, "", min_price=2000, max_price=3000)
        self.assertEqual([p["id"] for p in result], [1])

    def test_search_nothing_found(self):
        self.assertEqual(search_advanced(self.products, "xyz"), [])

    def test_search_query_none(self):
        self.assertEqual(len(search_advanced(self.products, None)), 5)


# --- Задание 2: total_sum и cart_total ---
class TestTotals(unittest.TestCase):
    def setUp(self):
        self.cart = [
            {"id": 1, "name": "A", "price": 100, "quantity": 2},
            {"id": 2, "name": "B", "price": 50, "quantity": 3},
        ]

    def test_total_sum_empty_cart(self):
        self.assertEqual(total_sum([]), 0)

    def test_total_sum_with_items(self):
        self.assertEqual(total_sum(self.cart), 350)

    def test_cart_total_empty(self):
        self.assertEqual(cart_total([]), 0)

    def test_cart_total_with_items(self):
        self.assertEqual(cart_total(self.cart), 350)


# --- Задание 3 и 5: add_to_cart ---
class TestAddToCart(unittest.TestCase):
    def setUp(self):
        self.products = make_products()
        self.cart = []

    def test_product_not_found(self):
        # в проекте нет размеров, поэтому проверяем несуществующий ID
        result, message = add_to_cart(self.cart, self.products, 99, 1)
        self.assertFalse(result)
        self.assertIn("не найден", message.lower())
        self.assertEqual(self.cart, [])

    def test_add_success(self):
        result, message = add_to_cart(self.cart, self.products, 1, 2)
        self.assertTrue(result)
        self.assertEqual(len(self.cart), 1)
        self.assertEqual(self.cart[0]["quantity"], 2)

    def test_add_twice_increases_quantity(self):
        add_to_cart(self.cart, self.products, 1, 2)
        add_to_cart(self.cart, self.products, 1, 1)
        self.assertEqual(len(self.cart), 1)
        self.assertEqual(self.cart[0]["quantity"], 3)

    def test_not_enough_stock(self):
        result, message = add_to_cart(self.cart, self.products, 2, 5)
        self.assertFalse(result)
        self.assertIn("недостаточно", message.lower())
        self.assertEqual(self.cart, [])

    def test_zero_quantity(self):
        result, message = add_to_cart(self.cart, self.products, 1, 0)
        self.assertFalse(result)


# --- Задание 5: remove_from_cart и update_quantity ---
class TestCartChanges(unittest.TestCase):
    def setUp(self):
        self.products = make_products()
        self.cart = [
            {"id": 1, "name": "Футбольный мяч", "price": 2500, "quantity": 2},
            {"id": 3, "name": "Гантели 5 кг", "price": 1800, "quantity": 1},
        ]

    def test_remove_from_cart(self):
        self.assertTrue(remove_from_cart(self.cart, 1))
        self.assertEqual([i["id"] for i in self.cart], [3])

    def test_remove_missing_item(self):
        self.assertFalse(remove_from_cart(self.cart, 99))
        self.assertEqual(len(self.cart), 2)

    def test_update_quantity(self):
        result, message = update_quantity(self.cart, self.products, 1, 5)
        self.assertTrue(result)
        self.assertEqual(self.cart[0]["quantity"], 5)

    def test_update_quantity_zero_removes_item(self):
        result, message = update_quantity(self.cart, self.products, 1, 0)
        self.assertTrue(result)
        self.assertEqual([i["id"] for i in self.cart], [3])

    def test_update_quantity_over_stock(self):
        result, message = update_quantity(self.cart, self.products, 1, 50)
        self.assertFalse(result)
        self.assertEqual(self.cart[0]["quantity"], 2)

    def test_update_quantity_not_in_cart(self):
        result, message = update_quantity(self.cart, self.products, 99, 1)
        self.assertFalse(result)


# --- Дополнительно: аналитика и заказы ---
class TestOther(unittest.TestCase):
    def test_count_by_category(self):
        self.assertEqual(
            count_by_category(make_products()),
            {"Мячи": 2, "Тренажёры": 2, "Обувь": 1},
        )

    def test_load_orders_missing_file(self):
        self.assertEqual(load_orders("no_such_file_12345.json"), [])

    def test_save_and_load_orders(self):
        orders = [{"items": [{"id": 1, "quantity": 2}], "total": 5000}]
        path = os.path.join(tempfile.mkdtemp(), "orders_test.json")
        save_orders(orders, path)
        self.assertEqual(load_orders(path), orders)


# --- Задание 3: ожидаемая ошибка ---
class TestErrors(unittest.TestCase):
    def test_division_by_zero(self):
        with self.assertRaises(ZeroDivisionError):
            _ = 1 / 0


if __name__ == "__main__":
    unittest.main()
