# Справочник API

Описание публичных функций модулей src/*.py.

## Форматы данных

**Товар** (словарь):

```python
{"id": 1, "name": "Футбольный мяч", "brand": "Adidas",
 "category": "Мячи", "price": 2500, "quantity": 10}
```

**Позиция корзины** (словарь):

```python
{"id": 1, "name": "Футбольный мяч", "price": 2500, "quantity": 2}
```

**Заказ** (словарь):

```python
{"client": "Анна", "date": "2026-10-11 21:32:45",
 "items": [ ...позиции корзины... ], "total": 6800}
```

Во всех примерах считается, что товары загружены так:

```python
from src.storage import load_products
products = load_products("data/products.json")
```

---

## src/catalog.py

### `find_product(products, product_id)`

Находит товар по ID.

**Параметры:**
- `products` (list[dict]) - список товаров.
- `product_id` (int) - ID искомого товара.

**Возвращает:**
- `dict` - товар, либо `None`, если такого ID нет.

**Исключения:**
- `KeyError` - если у товара в списке нет ключа `id`.

**Пример:**

```python
find_product(products, 3)["name"]   # "Гантели 5 кг"
find_product(products, 99)          # None
```

### `get_low_stock(products, threshold=3)`

Возвращает товары с низким остатком (количество не больше порога), по возрастанию количества.

**Параметры:**
- `products` (list[dict]) - список товаров.
- `threshold` (int, по умолчанию 3) - порог остатка, товар попадает в результат при `quantity <= threshold`.

**Возвращает:**
- `list[dict]` - товары с низким остатком, отсортированные по возрастанию `quantity`. Пустой список, если таких нет.

**Исключения:**
- `KeyError` - если у товара нет ключа `quantity`.

**Пример:**

```python
low = get_low_stock(products)
for p in low:
    print(p["name"], p["quantity"])
# Скакалка 1
# Баскетбольный мяч 2
# Гантели 5 кг 3
```

### `search_advanced(products, query, category=None, min_price=None, max_price=None)`

Комбинированный поиск: по тексту в названии или бренде, по категории и диапазону цен. Регистр не учитывается.

**Параметры:**
- `products` (list[dict]) - список товаров.
- `query` (str | None) - строка поиска; пустая строка или `None` означает "любой товар".
- `category` (str | None, по умолчанию None) - точное название категории.
- `min_price` (int | float | None, по умолчанию None) - минимальная цена включительно.
- `max_price` (int | float | None, по умолчанию None) - максимальная цена включительно.

**Возвращает:**
- `list[dict]` - подходящие товары (пустой список, если ничего не найдено).

**Исключения:**
- `KeyError` - если у товара нет ключей `name`, `brand`, `category` или `price`.

**Пример:**

```python
search_advanced(products, "nike")                    # товары с id 2 и 6
search_advanced(products, "мяч", "Мячи", None, 3000) # товар с id 1
search_advanced(products, "yoga")                    # []
```

### `count_by_category(products)`

Считает количество товаров в каждой категории.

**Параметры:**
- `products` (list[dict]) - список товаров.

**Возвращает:**
- `dict[str, int]` - словарь {категория: количество товаров}.

**Исключения:**
- `KeyError` - если у товара нет ключа `category`.

**Пример:**

```python
count_by_category(products)
# {"Мячи": 2, "Тренажёры": 2, "Обувь": 1, "Одежда": 1}
```

### `avg_price(products)`

Средняя цена товаров.

**Параметры:**
- `products` (list[dict]) - список товаров.

**Возвращает:**
- `float` - средняя цена, округлённая до 2 знаков; `0`, если список пуст.

**Исключения:**
- `KeyError` - если у товара нет ключа `price`.

**Пример:**

```python
avg_price(products)   # 2916.67
avg_price([])         # 0
```

---

## src/cart.py

### `add_to_cart(cart, products, product_id, quantity)`

Добавляет товар в корзину. Если товар уже в корзине, количество увеличивается. Количество в корзине не может превышать остаток на складе.

**Параметры:**
- `cart` (list[dict]) - корзина (изменяется на месте).
- `products` (list[dict]) - каталог товаров.
- `product_id` (int) - ID товара.
- `quantity` (int) - сколько штук добавить, должно быть больше 0.

**Возвращает:**
- `tuple[bool, str]` - (успех, сообщение). При ошибке корзина не меняется.

**Исключения:**
- Не выбрасывает: ошибки возвращаются как `(False, сообщение)`: товар не найден, количество не положительное, недостаточно товара на складе.

**Пример:**

```python
cart = []
add_to_cart(cart, products, 1, 2)    # (True, "Товар добавлен в корзину")
add_to_cart(cart, products, 99, 1)   # (False, "Товар с таким ID не найден")
add_to_cart(cart, products, 1, 0)    # (False, "Количество должно быть положительным числом")
```

### `remove_from_cart(cart, product_id)`

Удаляет позицию из корзины.

**Параметры:**
- `cart` (list[dict]) - корзина (изменяется на месте).
- `product_id` (int) - ID товара.

**Возвращает:**
- `bool` - `True`, если позиция удалена; `False`, если такой позиции нет.

**Исключения:**
- Нет.

**Пример:**

```python
remove_from_cart(cart, 1)   # True
remove_from_cart(cart, 1)   # False
```

### `update_quantity(cart, products, product_id, quantity)`

Меняет количество позиции в корзине. Если новое количество 0 или меньше, позиция удаляется.

**Параметры:**
- `cart` (list[dict]) - корзина (изменяется на месте).
- `products` (list[dict]) - каталог (нужен для проверки остатка).
- `product_id` (int) - ID товара.
- `quantity` (int) - новое количество.

**Возвращает:**
- `tuple[bool, str]` - (успех, сообщение): "Количество обновлено", "Товар удалён из корзины", "Товара нет в корзине" или сообщение о нехватке товара на складе.

**Исключения:**
- Не выбрасывает.

**Пример:**

```python
update_quantity(cart, products, 1, 5)   # (True, "Количество обновлено")
update_quantity(cart, products, 1, 0)   # (True, "Товар удалён из корзины")
```

### `cart_total(cart)`

Сумма корзины с учётом количества.

**Параметры:**
- `cart` (list[dict]) - корзина.

**Возвращает:**
- `int | float` - сумма цена * количество по всем позициям; `0` для пустой корзины.

**Исключения:**
- `KeyError` - если у позиции нет ключей `price` или `quantity`.

**Пример:**

```python
cart = []
add_to_cart(cart, products, 1, 2)
add_to_cart(cart, products, 3, 1)
cart_total(cart)   # 6800
```

### `total_sum(cart)`

Общая сумма корзины. Работает так же, как `cart_total` (оставлена для совместимости с ранними тестами).

**Параметры:**
- `cart` (list[dict]) - корзина.

**Возвращает:**
- `int | float` - сумма корзины.

**Исключения:**
- `KeyError` - если у позиции нет ключей `price` или `quantity`.

**Пример:**

```python
total_sum(cart)   # 6800
```

---

## src/orders.py

### `create_order(cart, client_name, products)`

Создаёт заказ из корзины и списывает купленные товары со склада (меняет `quantity` в списке `products`).

**Параметры:**
- `cart` (list[dict]) - корзина.
- `client_name` (str) - имя клиента.
- `products` (list[dict]) - каталог (остатки уменьшаются).

**Возвращает:**
- `dict` - заказ с ключами `client`, `date`, `items`, `total`; `None`, если корзина пуста.

**Исключения:**
- `ValueError` - товара из корзины нет в каталоге или на складе его меньше, чем в корзине (в этом случае склад не меняется).

**Пример:**

```python
cart = []
add_to_cart(cart, products, 1, 2)
order = create_order(cart, "Анна", products)
order["total"]            # 5000
products[0]["quantity"]   # 8
```

### `print_order(order)`

Выводит заказ в консоль.

**Параметры:**
- `order` (dict) - заказ, созданный `create_order`.

**Возвращает:**
- `None`.

**Исключения:**
- `KeyError` - если в заказе или его позициях не хватает ключей (`client`, `date`, `items`, `total`, `name`, `price`, `quantity`).

**Пример:**

```python
print_order(order)
# Заказ от 2026-10-11 21:32:45, клиент: Анна
#   Футбольный мяч x 2 = 5000 руб.
# Итого: 5000 руб.
```

### `save_orders(orders, filename="data/orders.json")`

Сохраняет список заказов в JSON-файл (папка создаётся, если её нет).

**Параметры:**
- `orders` (list[dict]) - список заказов.
- `filename` (str, по умолчанию "data/orders.json") - путь к файлу.

**Возвращает:**
- `None`.

**Исключения:**
- `OSError` - нет прав на запись или недоступен путь.
- `TypeError` - в заказах есть данные, которые нельзя записать в JSON.

**Пример:**

```python
save_orders([order], "data/orders.json")
```

### `load_orders(filename="data/orders.json")`

Загружает заказы из JSON-файла.

**Параметры:**
- `filename` (str, по умолчанию "data/orders.json") - путь к файлу.

**Возвращает:**
- `list[dict]` - список заказов. Если файла нет или он повреждён, возвращается пустой список.

**Исключения:**
- Не выбрасывает при отсутствии файла и при неверном JSON.

**Пример:**

```python
orders = load_orders("data/orders.json")
len(orders)   # 1
```

---

## src/analytics.py

### `total_revenue(orders)`

Общая выручка по всем заказам.

**Параметры:**
- `orders` (list[dict]) - список заказов.

**Возвращает:**
- `int | float` - сумма полей `total`; `0` для пустого списка.

**Исключения:**
- `KeyError` - если у заказа нет ключа `total`.

**Пример:**

```python
total_revenue(orders)   # 5000
```

### `best_selling_product(orders)`

Находит товар, проданный в наибольшем количестве штук по всем заказам.

**Параметры:**
- `orders` (list[dict]) - список заказов.

**Возвращает:**
- `str` - название товара; `None`, если заказов нет. При равенстве выбирается товар, встретившийся раньше.

**Исключения:**
- `KeyError` - если в заказе нет ключа `items` или в позиции нет `name` или `quantity`.

**Пример:**

```python
best_selling_product(orders)   # "Футбольный мяч"
best_selling_product([])       # None
```

### `average_order_total(orders)`

Средняя сумма заказа.

**Параметры:**
- `orders` (list[dict]) - список заказов.

**Возвращает:**
- `float` - средняя сумма, округлённая до 2 знаков; `0`, если заказов нет.

**Исключения:**
- `KeyError` - если у заказа нет ключа `total`.

**Пример:**

```python
average_order_total(orders)   # 5000.0
```

---

## src/storage.py

### `load_products(filename="data/products.json")`

Загружает каталог товаров из JSON-файла.

**Параметры:**
- `filename` (str, по умолчанию "data/products.json") - путь к файлу.

**Возвращает:**
- `list[dict]` - список товаров.

**Исключения:**
- `FileNotFoundError` - файл не найден.
- `json.JSONDecodeError` - файл содержит неверный JSON.

**Пример:**

```python
products = load_products("data/products.json")
len(products)   # 6
```

### `save_products(products, filename="data/products.json")`

Сохраняет каталог товаров в JSON-файл (папка создаётся, если её нет).

**Параметры:**
- `products` (list[dict]) - список товаров.
- `filename` (str, по умолчанию "data/products.json") - путь к файлу.

**Возвращает:**
- `None`.

**Исключения:**
- `OSError` - нет прав на запись или недоступен путь.

**Пример:**

```python
save_products(products, "data/products_backup.json")
```
