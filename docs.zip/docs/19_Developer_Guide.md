# Руководство разработчика

## 1. Настройка окружения

1. Установите Python 3.10 или выше и Git.
2. Установите VS Code и расширение **Python** (Microsoft).
3. Склонируйте проект и откройте его:

```
git clone https://github.com/netizeb/Hodotov3IP-7
cd SportShop
code .
```

4. Проверьте версии:

```
py --version
git --version
```

5. Сторонних зависимостей нет (файла requirements.txt в проекте нет). Если зависимости появятся, перечислите их в requirements.txt в корне, скрипт build.py установит их автоматически.

Необязательно: виртуальное окружение.

```
py -m venv .venv
.venv\Scripts\Activate.ps1
```

## 2. Запуск тестов

Из корня проекта (папка SportShop):

```
py -m unittest discover -s tests
```

Подробный вывод:

```
py -m unittest discover -s tests -v
```

Один файл тестов:

```
py -m unittest tests.test_cart
```

Один тест:

```
py -m unittest tests.test_cart.TestAddToCart.test_add_success
```

Ожидаемый результат: в конце строка `OK`.

## 3. Структура и правила проекта

- Каждый модуль отвечает за свою область: catalog (каталог), cart (корзина), orders (заказы), analytics (аналитика), storage (JSON-файлы товаров).
- Зависимости идут только "вниз": cart использует catalog, orders использует cart и catalog, main использует всё. Круговых импортов быть не должно.
- Формат данных товара, позиции корзины и заказа описан в docs/17_API_Reference.md. Изменение формата нужно согласовывать во всех модулях сразу.
- У каждой функции есть docstring: что делает и что возвращает.

## 4. Как добавить новую функцию

Пример: функция `get_top_expensive(products, n=3)`, возвращающая n самых дорогих товаров.

**Шаг 1.** Выберите модуль по назначению. Функция про каталог, значит, это `src/catalog.py`. Добавьте в конец файла:

```python
def get_top_expensive(products, n=3):
    """Возвращает n самых дорогих товаров (по убыванию цены)."""
    return sorted(products, key=lambda p: p["price"], reverse=True)[:n]
```

**Шаг 2.** Напишите тесты в `tests/test_catalog.py`. Добавьте `get_top_expensive` в импорт вверху файла и новый класс перед строкой `if __name__ == "__main__":`:

```python
class TestGetTopExpensive(unittest.TestCase):
    def test_top_two(self):
        result = get_top_expensive(make_products(), 2)
        self.assertEqual([p["id"] for p in result], [4, 2])

    def test_empty(self):
        self.assertEqual(get_top_expensive([]), [])
```

**Шаг 3.** Запустите тесты и убедитесь, что все проходят.

**Шаг 4.** Если функция нужна пользователю, подключите её в `main.py`: добавьте в импорт и новый пункт меню.

**Шаг 5.** Опишите функцию в `docs/17_API_Reference.md` по шаблону (назначение, параметры, возвращает, исключения, пример).

**Шаг 6.** Запустите сборку (раздел 6).

## 5. Как создать ветку и Pull Request

Основная ветка в примерах называется `main`. Если в вашем репозитории она называется иначе (например, `develop`), подставьте своё название.

```
git switch main
git pull
git switch -c feature/top-expensive
```

Внесите изменения, проверьте сборку, затем:

```
py build.py --no-run
git add .
git commit -m "Добавлена функция get_top_expensive"
git push -u origin feature/top-expensive
```

Дальше в браузере, в репозитории:

1. Нажмите кнопку **Compare & pull request** (она появится после push).
2. Проверьте, что base - `main`, compare - ваша ветка.
3. Напишите заголовок и описание: что добавлено и как проверено.
4. Нажмите **Create pull request**.
5. После проверки нажмите **Merge pull request**.

После слияния обновите локальную копию и удалите ветку:

```
git switch main
git pull
git branch -d feature/top-expensive
```

## 6. Как запустить сборку

```
py build.py
```

Скрипт выполняет 5 шагов:
1. проверка версии Python (нужна 3.10+);
2. установка зависимостей, если есть requirements.txt;
3. проверка наличия data/products.json;
4. запуск всех тестов;
5. запуск приложения (для выхода введите 0).

Если шаг не проходит, скрипт выводит сообщение и завершается с кодом 1.

Только проверки и тесты, без запуска приложения:

```
py build.py --no-run
```

## 7. Чек-лист перед коммитом

- Все тесты проходят (`OK`).
- `py build.py --no-run` заканчивается сообщением "Сборка успешна!".
- Документация обновлена, если менялись функции.
- Сообщение коммита описывает, что изменено.
