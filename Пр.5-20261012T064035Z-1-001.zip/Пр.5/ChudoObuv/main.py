# Практическая работа №5. Приложение "Чудо Обувь"

# ---------- Задание 1. Первая программа (шаг 6) ----------
print("Приложение Чудо Обувь запущено")
print("Добро пожаловать!")

# ---------- Задание 2. Переменные, print, for (шаги 8-11) ----------
login = "admin"
last_name = "Админов"
price = 8990.0
quantity = 5
in_stock = True

print("Логин:", login)
print("Фамилия:", last_name)
print("Цена:", price, "руб.")
print("Количество:", quantity)
print("В наличии:", in_stock)

sizes = [36.0, 37.0, 38.0, 39.0]
print("\nДоступные размеры:")
for s in sizes:
    print("-", s)

print("\nНомера по порядку:")
for i in range(len(sizes)):
    print(i + 1, "-", sizes[i])

if quantity <= 3:
    print("\nМало на складе")
else:
    print("\nДостаточно на складе")

# ---------- Задание 3. Списки и словари (шаги 12-13) ----------
users = [
    {'login': 'admin',   'last_name': 'Админов',       'role': 'администратор'},
    {'login': 'manager', 'last_name': 'Менеджеров',    'role': 'менеджер'},
    {'login': 'user',    'last_name': 'Пользователев', 'role': 'авторизованный'},
]

for u in users:
    print(f"Логин: {u['login']}, фамилия: {u['last_name']}, роль: {u['role']}")

products = [
    {'id': 1, 'name': 'Air Max',   'price': 8990.0, 'sizes': {36.0: 5, 37.0: 2}},
    {'id': 2, 'name': 'Superstar', 'price': 7490.0, 'sizes': {37.0: 4, 38.0: 3}},
    {'id': 3, 'name': 'Runfalcon', 'price': 5590.0, 'sizes': {39.0: 2}},
]

for p in products:
    total_qty = sum(p['sizes'].values())
    print(f"{p['name']} - {p['price']} руб., всего на складе: {total_qty} шт.")

# ---------- Задание 4. Функции (шаги 14-15) ----------
def find_user(login):
    for u in users:
        if u['login'] == login:
            return u
    return None


result = find_user('admin')
if result:
    print(f"Найден пользователь: {result['last_name']}")
else:
    print("Пользователь не найден")


def total_sum(items):
    total = 0
    for item in items:
        total += item['price'] * item['quantity']
    return total


cart = [
    {'name': 'Air Max',   'price': 8990.0, 'quantity': 2},
    {'name': 'Superstar', 'price': 7490.0, 'quantity': 1},
]

print(f"Итоговая сумма заказа: {total_sum(cart)} руб.")

# ---------- Задание 5. Сортировка и фильтрация (шаги 16-17) ----------
sorted_by_price = sorted(products, key=lambda p: p['price'])
print("\nТовары по возрастанию цены:")
for p in sorted_by_price:
    print(f"{p['name']} - {p['price']} руб.")

low_stock = [p for p in products if sum(p['sizes'].values()) <= 3]
print("\nТовары с низким остатком (<= 3 шт.):")
for p in low_stock:
    print(p['name'])

# ---------- Задание 6. Поиск по каталогу (шаги 18-19) ----------
def search_products(query):
    query = query.lower()
    return [p for p in products if query in p['name'].lower()]


found = search_products('max')
print("\nРезультаты поиска 'max':")
for p in found:
    print(p['name'])


def filter_by_price(products, min_price, max_price):
    return [p for p in products if min_price <= p['price'] <= max_price]


result = filter_by_price(products, 5000, 8000)
print("\nТовары от 5000 до 8000 руб.:")
for p in result:
    print(f"{p['name']} - {p['price']} руб.")

# ---------- Задание 7. Мини-задача "Корзина" (шаг 20) ----------
def add_to_cart(cart, product, size, quantity):
    cart.append({
        'product': product['name'],
        'price': product['price'],
        'size': size,
        'quantity': quantity
    })


def remove_from_cart(cart, name):
    cart[:] = [item for item in cart if item['product'] != name]


def change_quantity(cart, name, new_qty):
    for item in cart:
        if item['product'] == name:
            item['quantity'] = new_qty
            break


cart = []
add_to_cart(cart, products[0], 36.0, 2)
add_to_cart(cart, products[1], 37.0, 1)

print("\nКорзина:")
for item in cart:
    print(f"{item['product']}, размер {item['size']}, "
          f"{item['quantity']} шт. x {item['price']} = "
          f"{item['quantity'] * item['price']} руб.")

print(f"\nИтого: {total_sum(cart)} руб.")

change_quantity(cart, 'Air Max', 3)
remove_from_cart(cart, 'Superstar')

print("\nПосле изменений:")
for item in cart:
    print(f"{item['product']}, размер {item['size']}, {item['quantity']} шт.")
print(f"Итого: {total_sum(cart)} руб.")

# ---------- Задание 8. Самостоятельно ----------
print("\n===== Задание 8 =====")

# 1. Два новых товара с разными размерами и ценами
products.append({'id': 4, 'name': 'Stan Smith',  'price': 5290.0,  'sizes': {36.0: 1, 37.0: 2}})
products.append({'id': 5, 'name': 'Ultraboost',  'price': 14990.0, 'sizes': {38.0: 4, 39.0: 3, 40.0: 5}})
print("\n1. Каталог после добавления товаров:")
for p in products:
    print(f"{p['id']}. {p['name']} - {p['price']} руб.")


# 2. Функция get_sizes(product): список доступных размеров
def get_sizes(product):
    return sorted(size for size, qty in product['sizes'].items() if qty > 0)


# 3. Функция get_total_quantity(product): общее количество единиц
def get_total_quantity(product):
    return sum(product['sizes'].values())


print("\n2-3. Размеры и количество по каждому товару:")
for p in products:
    print(f"{p['name']}: размеры {get_sizes(p)}, всего {get_total_quantity(p)} шт.")

# 4. Сортировка товаров по названию (по алфавиту)
sorted_by_name = sorted(products, key=lambda p: p['name'])
print("\n4. Товары по алфавиту:")
for p in sorted_by_name:
    print(p['name'])

# 5. Товары дешевле 6000 рублей
cheap = [p for p in products if p['price'] < 6000]
print("\n5. Товары дешевле 6000 руб.:")
for p in cheap:
    print(f"{p['name']} - {p['price']} руб.")

# 6. Вывод товаров по одному с помощью while, пока они не закончатся
print("\n6. Вывод через while:")
queue = products.copy()
while len(queue) > 0:
    p = queue.pop(0)
    print(f"{p['name']} - {p['price']} руб. (осталось в очереди: {len(queue)})")
