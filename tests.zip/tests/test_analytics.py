import unittest

from src.analytics import total_revenue, best_selling_product, average_order_total


def make_orders():
    return [
        {"total": 5000, "items": [{"name": "A", "quantity": 2}, {"name": "B", "quantity": 1}]},
        {"total": 1000, "items": [{"name": "B", "quantity": 4}]},
    ]


class TestTotalRevenue(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(total_revenue([]), 0)

    def test_with_orders(self):
        self.assertEqual(total_revenue(make_orders()), 6000)


class TestBestSellingProduct(unittest.TestCase):
    def test_no_orders(self):
        self.assertIsNone(best_selling_product([]))

    def test_with_orders(self):
        # A: 2 шт., B: 1 + 4 = 5 шт.
        self.assertEqual(best_selling_product(make_orders()), "B")


class TestAverageOrderTotal(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(average_order_total([]), 0)

    def test_with_orders(self):
        self.assertEqual(average_order_total(make_orders()), 3000.0)


if __name__ == "__main__":
    unittest.main()