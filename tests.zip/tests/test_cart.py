import unittest

from src.cart import (
    cart_total,
    total_sum,
    add_to_cart,
    remove_from_cart,
    update_quantity,
)


def make_products():
    return [
        {"id": 1, "name": "Футбольный мяч", "brand": "Adidas", "category": "Мячи", "price": 2500, "quantity": 10},
        {"id": 2, "name": "Баскетбольный мяч", "brand": "Nike", "category": "Мячи", "price": 3200, "quantity": 2},
        {"id": 3, "name": "Гантели 5 кг", "brand": "Torneo", "category": "Тренажёры", "price": 1800, "quantity": 3},
    ]


class TestTotals(unittest.TestCase):
    def setUp(self):
        self.cart = [
            {"id": 1, "name": "A", "price": 100, "quantity": 2},
            {"id": 2, "name": "B", "price": 50, "quantity": 3},
        ]

    def test_total_sum_empty_cart(self):
        self.assertEqual(total_sum([]), 0)

    def test_total_sum_with_items(self):
        self.assertEqual(total_sum(self.cart), 350)

    def test_cart_total_empty(self):
        self.assertEqual(cart_total([]), 0)

    def test_cart_total_with_items(self):
        self.assertEqual(cart_total(self.cart), 350)


class TestAddToCart(unittest.TestCase):
    def setUp(self):
        self.products = make_products()
        self.cart = []

    def test_product_not_found(self):
        result, message = add_to_cart(self.cart, self.products, 99, 1)
        self.assertFalse(result)
        self.assertIn("не найден", message.lower())
        self.assertEqual(self.cart, [])

    def test_add_success(self):
        result, message = add_to_cart(self.cart, self.products, 1, 2)
        self.assertTrue(result)
        self.assertEqual(len(self.cart), 1)
        self.assertEqual(self.cart[0]["quantity"], 2)

    def test_cart_item_has_name_and_price(self):
        add_to_cart(self.cart, self.products, 1, 2)
        self.assertEqual(self.cart[0]["name"], "Футбольный мяч")
        self.assertEqual(self.cart[0]["price"], 2500)

    def test_add_twice_increases_quantity(self):
        add_to_cart(self.cart, self.products, 1, 2)
        add_to_cart(self.cart, self.products, 1, 1)
        self.assertEqual(len(self.cart), 1)
        self.assertEqual(self.cart[0]["quantity"], 3)

    def test_not_enough_stock(self):
        result, message = add_to_cart(self.cart, self.products, 2, 5)
        self.assertFalse(result)
        self.assertIn("недостаточно", message.lower())
        self.assertEqual(self.cart, [])

    def test_zero_quantity(self):
        result, message = add_to_cart(self.cart, self.products, 1, 0)
        self.assertFalse(result)


class TestCartChanges(unittest.TestCase):
    def setUp(self):
        self.products = make_products()
        self.cart = [
            {"id": 1, "name": "Футбольный мяч", "price": 2500, "quantity": 2},
            {"id": 3, "name": "Гантели 5 кг", "price": 1800, "quantity": 1},
        ]

    def test_remove_from_cart(self):
        self.assertTrue(remove_from_cart(self.cart, 1))
        self.assertEqual([i["id"] for i in self.cart], [3])

    def test_remove_missing_item(self):
        self.assertFalse(remove_from_cart(self.cart, 99))
        self.assertEqual(len(self.cart), 2)

    def test_update_quantity(self):
        result, message = update_quantity(self.cart, self.products, 1, 5)
        self.assertTrue(result)
        self.assertEqual(self.cart[0]["quantity"], 5)

    def test_update_quantity_zero_removes_item(self):
        result, message = update_quantity(self.cart, self.products, 1, 0)
        self.assertTrue(result)
        self.assertEqual([i["id"] for i in self.cart], [3])

    def test_update_quantity_over_stock(self):
        result, message = update_quantity(self.cart, self.products, 1, 50)
        self.assertFalse(result)
        self.assertEqual(self.cart[0]["quantity"], 2)

    def test_update_quantity_not_in_cart(self):
        result, message = update_quantity(self.cart, self.products, 99, 1)
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()