import unittest

from src.catalog import (
    find_product,
    get_low_stock,
    search_advanced,
    count_by_category,
    avg_price,
)


def make_products():
    """Свежий набор тестовых товаров для каждого теста."""
    return [
        {"id": 1, "name": "Футбольный мяч", "brand": "Adidas", "category": "Мячи", "price": 2500, "quantity": 10},
        {"id": 2, "name": "Баскетбольный мяч", "brand": "Nike", "category": "Мячи", "price": 3200, "quantity": 2},
        {"id": 3, "name": "Гантели 5 кг", "brand": "Torneo", "category": "Тренажёры", "price": 1800, "quantity": 3},
        {"id": 4, "name": "Беговые кроссовки", "brand": "Asics", "category": "Обувь", "price": 7500, "quantity": 6},
        {"id": 5, "name": "Скакалка", "brand": "Demix", "category": "Тренажёры", "price": 600, "quantity": 1},
    ]


class TestFindProduct(unittest.TestCase):
    def test_found(self):
        self.assertEqual(find_product(make_products(), 3)["name"], "Гантели 5 кг")

    def test_not_found(self):
        self.assertIsNone(find_product(make_products(), 99))


class TestGetLowStock(unittest.TestCase):
    def test_empty_list(self):
        self.assertEqual(get_low_stock([]), [])

    def test_no_low_stock(self):
        products = [{"name": "A", "quantity": 10}]
        self.assertEqual(get_low_stock(products), [])

    def test_one_low_stock(self):
        products = [
            {"name": "A", "quantity": 1},
            {"name": "B", "quantity": 10},
        ]
        result = get_low_stock(products)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["name"], "A")

    def test_default_threshold_is_3(self):
        # остаток 3 попадает (<=), остаток 4 - уже нет
        products = [
            {"name": "A", "quantity": 3},
            {"name": "B", "quantity": 4},
        ]
        result = get_low_stock(products)
        self.assertEqual([p["name"] for p in result], ["A"])

    def test_sorted_by_quantity(self):
        result = get_low_stock(make_products())
        self.assertEqual([p["quantity"] for p in result], [1, 2, 3])


class TestSearchAdvanced(unittest.TestCase):
    def setUp(self):
        self.products = make_products()

    def test_search_by_name(self):
        result = search_advanced(self.products, "гантели")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["id"], 3)

    def test_search_by_brand(self):
        result = search_advanced(self.products, "nike")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["id"], 2)

    def test_search_by_category(self):
        result = search_advanced(self.products, "", category="Мячи")
        self.assertEqual([p["id"] for p in result], [1, 2])

    def test_search_by_price(self):
        result = search_advanced(self.products, "", min_price=2000, max_price=3000)
        self.assertEqual([p["id"] for p in result], [1])

    def test_search_nothing_found(self):
        self.assertEqual(search_advanced(self.products, "xyz"), [])

    def test_search_query_none(self):
        self.assertEqual(len(search_advanced(self.products, None)), 5)


class TestCountByCategory(unittest.TestCase):
    def test_count_by_category(self):
        self.assertEqual(
            count_by_category(make_products()),
            {"Мячи": 2, "Тренажёры": 2, "Обувь": 1},
        )


class TestAvgPrice(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(avg_price([]), 0)

    def test_with_products(self):
        # (2500 + 3200 + 1800 + 7500 + 600) / 5 = 3120
        self.assertEqual(avg_price(make_products()), 3120.0)


if __name__ == "__main__":
    unittest.main()