import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout

from src.orders import create_order, print_order, save_orders, load_orders


def make_products():
    return [
        {"id": 1, "name": "Футбольный мяч", "brand": "Adidas", "category": "Мячи", "price": 2500, "quantity": 10},
        {"id": 2, "name": "Баскетбольный мяч", "brand": "Nike", "category": "Мячи", "price": 3200, "quantity": 2},
    ]


def make_cart():
    return [{"id": 1, "name": "Футбольный мяч", "price": 2500, "quantity": 2}]


class TestCreateOrder(unittest.TestCase):
    def setUp(self):
        self.products = make_products()

    def test_create_order_success(self):
        order = create_order(make_cart(), "Иван", self.products)
        self.assertEqual(order["client"], "Иван")
        self.assertEqual(order["total"], 5000)
        self.assertEqual(len(order["items"]), 1)
        self.assertIn("date", order)

    def test_empty_cart_returns_none(self):
        self.assertIsNone(create_order([], "Иван", self.products))

    def test_stock_is_reduced(self):
        create_order(make_cart(), "Иван", self.products)
        self.assertEqual(self.products[0]["quantity"], 8)

    def test_not_enough_stock_raises(self):
        cart = [{"id": 2, "name": "Баскетбольный мяч", "price": 3200, "quantity": 5}]
        with self.assertRaises(ValueError):
            create_order(cart, "Иван", self.products)
        self.assertEqual(self.products[1]["quantity"], 2)

    def test_unknown_product_raises(self):
        cart = [{"id": 99, "name": "Нет такого", "price": 1, "quantity": 1}]
        with self.assertRaises(ValueError):
            create_order(cart, "Иван", self.products)


class TestPrintOrder(unittest.TestCase):
    def test_print_order_output(self):
        order = create_order(make_cart(), "Иван", make_products())
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            print_order(order)
        text = buffer.getvalue()
        self.assertIn("Иван", text)
        self.assertIn("Футбольный мяч", text)
        self.assertIn("Итого: 5000", text)


class TestSaveLoadOrders(unittest.TestCase):
    def test_save_and_load(self):
        orders = [{"client": "Иван", "date": "2026-01-01 10:00:00",
                   "items": [{"id": 1, "name": "A", "price": 10, "quantity": 2}], "total": 20}]
        path = os.path.join(tempfile.mkdtemp(), "orders_test.json")
        save_orders(orders, path)
        self.assertEqual(load_orders(path), orders)

    def test_load_missing_file(self):
        self.assertEqual(load_orders("no_such_file_12345.json"), [])

    def test_load_broken_json(self):
        path = os.path.join(tempfile.mkdtemp(), "broken.json")
        with open(path, "w", encoding="utf-8") as f:
            f.write("{ это не json")
        self.assertEqual(load_orders(path), [])


if __name__ == "__main__":
    unittest.main()