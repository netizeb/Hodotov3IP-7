import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout

from src.catalog import get_low_stock
from src.cart import add_to_cart, cart_total
from src.orders import create_order, print_order, save_orders, load_orders
from src.analytics import total_revenue, best_selling_product
from src.storage import load_products, save_products

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRODUCTS_FILE = os.path.join(BASE_DIR, "data", "products.json")


class TestIntegration(unittest.TestCase):
    def setUp(self):
        self.products = load_products(PRODUCTS_FILE)
        self.cart = []
        self.orders_file = os.path.join(BASE_DIR, "data", "test_orders.json")

    def tearDown(self):
        if os.path.exists(self.orders_file):
            os.remove(self.orders_file)

    def test_full_cycle(self):
        # 1. Добавляем товар в корзину
        result, msg = add_to_cart(self.cart, self.products, 1, 2)
        self.assertTrue(result)

        # 2. Создаём заказ
        order = create_order(self.cart, "Тестовый клиент", self.products)
        self.assertIsNotNone(order)
        self.assertGreater(order["total"], 0)
        self.assertEqual(order["total"], cart_total(self.cart))

        # 3. Сохраняем и загружаем
        save_orders([order], self.orders_file)
        loaded = load_orders(self.orders_file)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0]["total"], order["total"])

        # 4. Аналитика работает с загруженным заказом
        self.assertEqual(total_revenue(loaded), order["total"])
        self.assertEqual(best_selling_product(loaded), "Футбольный мяч")

    def test_print_order_after_load(self):
        add_to_cart(self.cart, self.products, 1, 2)
        order = create_order(self.cart, "Тестовый клиент", self.products)
        save_orders([order], self.orders_file)
        loaded = load_orders(self.orders_file)

        buffer = io.StringIO()
        with redirect_stdout(buffer):
            print_order(loaded[0])
        self.assertIn("Футбольный мяч", buffer.getvalue())

    def test_stock_changes_after_order(self):
        add_to_cart(self.cart, self.products, 1, 2)
        create_order(self.cart, "Тестовый клиент", self.products)
        # было 10, купили 2
        self.assertEqual(self.products[0]["quantity"], 8)
        # товар с низким остатком по-прежнему находится в каталоге
        self.assertIn(2, [p["id"] for p in get_low_stock(self.products)])

    def test_order_too_many_items_fails(self):
        ok, msg = add_to_cart(self.cart, self.products, 2, 100)
        self.assertFalse(ok)
        self.assertIsNone(create_order(self.cart, "Тестовый клиент", self.products))

    def test_products_file_is_valid(self):
        self.assertTrue(os.path.exists(PRODUCTS_FILE))
        required = {"id", "name", "brand", "category", "price", "quantity"}
        for product in self.products:
            self.assertTrue(required.issubset(product.keys()))

    def test_save_and_load_products(self):
        path = os.path.join(tempfile.mkdtemp(), "products_copy.json")
        save_products(self.products, path)
        self.assertEqual(load_products(path), self.products)


if __name__ == "__main__":
    unittest.main()