"""Скрипт локальной сборки проекта СпортТовары."""

import os
import subprocess
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def check_python_version():
    """Шаг 1. Проверка версии Python."""
    if sys.version_info < (3, 10):
        print("Требуется Python 3.10+")
        sys.exit(1)
    print(f"[1/5] Python {sys.version_info.major}.{sys.version_info.minor} - OK")


def install_dependencies():
    """Шаг 2. Установка зависимостей (если есть requirements.txt)."""
    requirements = os.path.join(BASE_DIR, "requirements.txt")
    if not os.path.exists(requirements):
        print("[2/5] Зависимостей нет - пропуск")
        return
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", requirements],
        cwd=BASE_DIR,
    )
    if result.returncode != 0:
        print("Не удалось установить зависимости!")
        sys.exit(1)
    print("[2/5] Зависимости установлены - OK")


def check_data():
    """Шаг 3. Проверка наличия файла данных."""
    path = os.path.join(BASE_DIR, "data", "products.json")
    if not os.path.exists(path):
        print("Файл данных не найден: data/products.json")
        sys.exit(1)
    print("[3/5] data/products.json найден - OK")


def run_tests():
    """Шаг 4. Запуск всех тестов."""
    result = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests"],
        capture_output=True, text=True, errors="replace", cwd=BASE_DIR,
    )
    print(result.stdout)
    print(result.stderr)  # unittest пишет результат в stderr
    if result.returncode != 0:
        print("Тесты не прошли!")
        sys.exit(1)
    print("[4/5] Тесты - OK")


def run_app():
    """Шаг 5. Запуск приложения."""
    print("[5/5] Запуск приложения (для выхода введите 0)...")
    subprocess.run([sys.executable, "main.py"], cwd=BASE_DIR)


if __name__ == "__main__":
    check_python_version()
    install_dependencies()
    check_data()
    run_tests()
    print("Сборка успешна!")
    if "--no-run" in sys.argv:
        print("Запуск приложения пропущен (--no-run).")
    else:
        run_app()