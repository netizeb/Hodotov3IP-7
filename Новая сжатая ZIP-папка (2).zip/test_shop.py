import unittest
from shop import get_low_stock, search_advanced, count_by_category, cart_total

PRODUCTS = [
    {"id": 1, "name": "Мяч", "brand": "Nike", "category": "Мячи", "price": 1000, "quantity": 5},
    {"id": 2, "name": "Скакалка", "brand": "Demix", "category": "Тренажёры", "price": 500, "quantity": 1},
    {"id": 3, "name": "Гантели", "brand": "Torneo", "category": "Тренажёры", "price": 1500, "quantity": 3},
]


class TestShop(unittest.TestCase):
    def test_get_low_stock(self):
        result = get_low_stock(PRODUCTS)
        self.assertEqual([p["id"] for p in result], [2, 3])

    def test_get_low_stock_empty(self):
        self.assertEqual(get_low_stock([PRODUCTS[0]]), [])

    def test_search_advanced(self):
        result = search_advanced(PRODUCTS, "nike")
        self.assertEqual([p["id"] for p in result], [1])
        result = search_advanced(PRODUCTS, "", category="Тренажёры", max_price=1000)
        self.assertEqual([p["id"] for p in result], [2])

    def test_count_by_category(self):
        self.assertEqual(count_by_category(PRODUCTS), {"Мячи": 1, "Тренажёры": 2})

    def test_cart_total(self):
        cart = [{"price": 1000, "quantity": 2}, {"price": 500, "quantity": 1}]
        self.assertEqual(cart_total(cart), 2500)
        self.assertEqual(cart_total([]), 0)


if __name__ == "__main__":
    unittest.main()