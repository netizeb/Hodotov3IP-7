"""СпортТовары - учебный проект интернет-магазина (точка входа)."""

import os

from src.catalog import get_low_stock, search_advanced, count_by_category, avg_price
from src.cart import add_to_cart, cart_total
from src.orders import create_order, print_order, save_orders, load_orders
from src.analytics import total_revenue, best_selling_product, average_order_total
from src.storage import load_products

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PRODUCTS_FILE = os.path.join(BASE_DIR, "data", "products.json")
ORDERS_FILE = os.path.join(BASE_DIR, "data", "orders.json")


def show_products(products):
    """Вывод списка товаров в консоль."""
    if not products:
        print("Ничего не найдено.")
        return
    for p in products:
        print(f"{p['id']}. {p['name']} ({p['brand']}), {p['category']} - "
              f"{p['price']} руб., остаток: {p['quantity']}")


def ask_number(prompt):
    raw = input(prompt).strip()
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        print("Это не число, параметр пропущен.")
        return None


def make_order(products):
    """Интерактивное оформление заказа: корзина -> заказ -> сохранение."""
    cart = []
    while True:
        raw_id = input("ID товара (Enter - завершить): ").strip()
        if not raw_id:
            break
        if not raw_id.isdigit():
            print("ID должен быть числом.")
            continue
        raw_qty = input("Количество: ").strip()
        if not raw_qty.isdigit():
            print("Количество должно быть числом.")
            continue
        ok, message = add_to_cart(cart, products, int(raw_id), int(raw_qty))
        print(message)
        if ok:
            print(f"Сумма корзины: {cart_total(cart)} руб.")

    if not cart:
        print("Корзина пуста, заказ не оформлен.")
        return

    client_name = input("Имя клиента: ").strip() or "Без имени"
    try:
        order = create_order(cart, client_name, products)
    except ValueError as error:
        print(f"Заказ не оформлен: {error}")
        return

    orders = load_orders(ORDERS_FILE)
    orders.append(order)
    save_orders(orders, ORDERS_FILE)
    print_order(order)
    print("Заказ сохранён в data/orders.json")


def show_order_stats():
    """Статистика по сохранённым заказам."""
    orders = load_orders(ORDERS_FILE)
    if not orders:
        print("Заказов пока нет.")
        return
    print(f"Заказов: {len(orders)}")
    print(f"Общая выручка: {total_revenue(orders)} руб.")
    print(f"Средний заказ: {average_order_total(orders)} руб.")
    print(f"Самый продаваемый товар: {best_selling_product(orders)}")


def main():
    products = load_products(PRODUCTS_FILE)
    while True:
        print("\n=== СпортТовары ===")
        print("1. Показать все товары")
        print("2. Товары с низким остатком")
        print("3. Поиск товаров")
        print("4. Аналитика по каталогу")
        print("5. Оформить заказ")
        print("6. Статистика заказов")
        print("0. Выход")
        choice = input("Выберите пункт: ").strip()

        if choice == "1":
            show_products(products)
        elif choice == "2":
            low = get_low_stock(products)
            if low:
                show_products(low)
            else:
                print("Нет товаров с низким остатком")
        elif choice == "3":
            query = input("Название или бренд: ")
            category = input("Категория (Enter - любая): ").strip() or None
            min_price = ask_number("Мин. цена (Enter - без ограничения): ")
            max_price = ask_number("Макс. цена (Enter - без ограничения): ")
            show_products(search_advanced(products, query, category, min_price, max_price))
        elif choice == "4":
            for category, count in count_by_category(products).items():
                print(f"{category}: {count}")
            print(f"Средняя цена товара: {avg_price(products)} руб.")
        elif choice == "5":
            show_products(products)
            make_order(products)
        elif choice == "6":
            show_order_stats()
        elif choice == "0":
            print("До свидания!")
            break
        else:
            print("Неверный пункт меню.")


if __name__ == "__main__":
    main()