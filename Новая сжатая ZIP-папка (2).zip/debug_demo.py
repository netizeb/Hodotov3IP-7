from src.storage import load_products
from src.catalog import get_low_stock

products = load_products("data/products.json")
result = get_low_stock(products)
print(result)