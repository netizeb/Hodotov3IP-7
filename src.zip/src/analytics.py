"""Аналитика по заказам."""


def total_revenue(orders):
    """Общая выручка по всем заказам."""
    return sum(order["total"] for order in orders)


def best_selling_product(orders):
    """Название товара, проданного в наибольшем количестве (None, если заказов нет)."""
    sold = {}
    for order in orders:
        for item in order["items"]:
            sold[item["name"]] = sold.get(item["name"], 0) + item["quantity"]
    if not sold:
        return None
    return max(sold, key=sold.get)


def average_order_total(orders):
    """Средняя сумма заказа (0, если заказов нет)."""
    if not orders:
        return 0
    return round(total_revenue(orders) / len(orders), 2)