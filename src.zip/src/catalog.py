"""Каталог товаров: поиск, фильтры, статистика."""


def find_product(products, product_id):
    """Возвращает товар по ID или None, если не найден."""
    return next((p for p in products if p["id"] == product_id), None)


def get_low_stock(products, threshold=3):
    """Возвращает товары с количеством <= threshold, по возрастанию количества."""
    low = [p for p in products if p["quantity"] <= threshold]
    return sorted(low, key=lambda p: p["quantity"])


def search_advanced(products, query, category=None, min_price=None, max_price=None):
    """Комбинированный поиск по названию/бренду, категории и диапазону цен."""
    q = (query or "").strip().lower()
    result = []
    for p in products:
        if q not in p["name"].lower() and q not in p["brand"].lower():
            continue
        if category and p["category"].lower() != category.lower():
            continue
        if min_price is not None and p["price"] < min_price:
            continue
        if max_price is not None and p["price"] > max_price:
            continue
        result.append(p)
    return result


def count_by_category(products):
    """Словарь {категория: количество товаров}."""
    result = {}
    for p in products:
        result[p["category"]] = result.get(p["category"], 0) + 1
    return result


def avg_price(products):
    """Средняя цена товаров (0, если список пуст)."""
    if not products:
        return 0
    return round(sum(p["price"] for p in products) / len(products), 2)