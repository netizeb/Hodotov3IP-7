"""Корзина: добавление, удаление, изменение количества, сумма."""

from src.catalog import find_product


def cart_total(cart):
    """Сумма корзины с учётом количества."""
    return sum(item["price"] * item["quantity"] for item in cart)


def total_sum(cart):
    """Общая сумма корзины (то же, что cart_total)."""
    return cart_total(cart)


def add_to_cart(cart, products, product_id, quantity):
    """Добавляет товар в корзину. Возвращает (True/False, сообщение)."""
    product = find_product(products, product_id)
    if product is None:
        return False, "Товар с таким ID не найден"
    if quantity <= 0:
        return False, "Количество должно быть положительным числом"
    for item in cart:
        if item["id"] == product_id:
            if item["quantity"] + quantity > product["quantity"]:
                return False, f"Недостаточно товара на складе. Доступно: {product['quantity']} шт."
            item["quantity"] += quantity
            return True, "Количество в корзине увеличено"
    if quantity > product["quantity"]:
        return False, f"Недостаточно товара на складе. Доступно: {product['quantity']} шт."
    cart.append({"id": product["id"], "name": product["name"],
                 "price": product["price"], "quantity": quantity})
    return True, "Товар добавлен в корзину"


def remove_from_cart(cart, product_id):
    """Удаляет позицию из корзины. True - удалили, False - такой позиции нет."""
    for item in cart:
        if item["id"] == product_id:
            cart.remove(item)
            return True
    return False


def update_quantity(cart, products, product_id, quantity):
    """Меняет количество позиции. Если quantity <= 0, позиция удаляется."""
    item = next((i for i in cart if i["id"] == product_id), None)
    if item is None:
        return False, "Товара нет в корзине"
    if quantity <= 0:
        cart.remove(item)
        return True, "Товар удалён из корзины"
    product = find_product(products, product_id)
    if product is not None and quantity > product["quantity"]:
        return False, f"Недостаточно товара на складе. Доступно: {product['quantity']} шт."
    item["quantity"] = quantity
    return True, "Количество обновлено"