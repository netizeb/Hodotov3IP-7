"""Заказы: создание, вывод, сохранение и загрузка."""

import json
import os
from datetime import datetime

from src.cart import cart_total
from src.catalog import find_product

ORDERS_FILE = "data/orders.json"


def create_order(cart, client_name, products):
    """Создаёт заказ из корзины и списывает товары со склада.

    Возвращает заказ (словарь) или None, если корзина пуста.
    Если товара не хватает или его нет в каталоге - ValueError.
    """
    if not cart:
        return None

    for item in cart:
        product = find_product(products, item["id"])
        if product is None:
            raise ValueError(f"Товар с ID {item['id']} не найден в каталоге")
        if item["quantity"] > product["quantity"]:
            raise ValueError(f"Недостаточно товара на складе: {product['name']}")

    for item in cart:
        find_product(products, item["id"])["quantity"] -= item["quantity"]

    return {
        "client": client_name,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "items": [dict(item) for item in cart],
        "total": cart_total(cart),
    }


def print_order(order):
    """Выводит заказ в консоль."""
    print(f"Заказ от {order['date']}, клиент: {order['client']}")
    for item in order["items"]:
        print(f"  {item['name']} x {item['quantity']} = {item['price'] * item['quantity']} руб.")
    print(f"Итого: {order['total']} руб.")


def save_orders(orders, filename=ORDERS_FILE):
    """Сохраняет заказы в JSON-файл."""
    folder = os.path.dirname(filename)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(orders, f, ensure_ascii=False, indent=2)


def load_orders(filename=ORDERS_FILE):
    """Загружает заказы (или пустой список, если файла нет или он повреждён)."""
    if not os.path.exists(filename):
        return []
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        return []