"""Сохранение и загрузка товаров в JSON."""

import json
import os


def load_products(filename="data/products.json"):
    """Загружает список товаров из JSON-файла."""
    with open(filename, "r", encoding="utf-8") as f:
        return json.load(f)


def save_products(products, filename="data/products.json"):
    """Сохраняет список товаров в JSON-файл."""
    folder = os.path.dirname(filename)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(products, f, ensure_ascii=False, indent=2)