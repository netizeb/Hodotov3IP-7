"""СпортТовары — учебный проект интернет-магазина."""

import json
import os

# --- Данные ---
PRODUCTS = [
    {"id": 1, "name": "Футбольный мяч", "brand": "Adidas", "category": "Мячи", "price": 2500, "quantity": 10},
    {"id": 2, "name": "Баскетбольный мяч", "brand": "Nike", "category": "Мячи", "price": 3200, "quantity": 2},
    {"id": 3, "name": "Гантели 5 кг", "brand": "Torneo", "category": "Тренажёры", "price": 1800, "quantity": 3},
    {"id": 4, "name": "Беговые кроссовки", "brand": "Asics", "category": "Обувь", "price": 7500, "quantity": 6},
    {"id": 5, "name": "Скакалка", "brand": "Demix", "category": "Тренажёры", "price": 600, "quantity": 1},
    {"id": 6, "name": "Футболка спортивная", "brand": "Nike", "category": "Одежда", "price": 1900, "quantity": 15},
]


def show_products(products):
    """Вывод списка товаров в консоль."""
    if not products:
        print("Ничего не найдено.")
        return
    for p in products:
        print(f"{p['id']}. {p['name']} ({p['brand']}), {p['category']} — "
              f"{p['price']} руб., остаток: {p['quantity']}")


# --- US-1. Низкий остаток ---
def get_low_stock(products, threshold=3):
    """Возвращает товары с количеством <= threshold, по возрастанию количества."""
    low = [p for p in products if p["quantity"] <= threshold]
    return sorted(low, key=lambda p: p["quantity"])


# --- US-2. Поиск ---
def search_advanced(products, query, category=None, min_price=None, max_price=None):
    """Комбинированный поиск по названию/бренду, категории и диапазону цен."""
    q = query.lower()
    result = []
    for p in products:
        if q not in p["name"].lower() and q not in p["brand"].lower():
            continue
        if category and p["category"].lower() != category.lower():
            continue
        if min_price is not None and p["price"] < min_price:
            continue
        if max_price is not None and p["price"] > max_price:
            continue
        result.append(p)
    return result


# --- US-3. Аналитика ---
def count_by_category(products):
    """Словарь {категория: количество товаров}."""
    result = {}
    for p in products:
        result[p["category"]] = result.get(p["category"], 0) + 1
    return result


# --- US-6. Сумма корзины ---
def cart_total(cart):
    """Сумма корзины с учётом количества."""
    return sum(item["price"] * item["quantity"] for item in cart)


# --- US-4. Заказы ---
def load_orders(filename="orders.json"):
    """Загружает ранее сохранённые заказы (или пустой список)."""
    if not os.path.exists(filename):
        return []
    with open(filename, "r", encoding="utf-8") as f:
        return json.load(f)


def save_orders(orders, filename="orders.json"):
    """Сохраняет заказы в JSON-файл."""
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(orders, f, ensure_ascii=False, indent=2)


def create_order(products):
    """Интерактивное оформление заказа. Возвращает заказ или None."""
    cart = []
    while True:
        raw_id = input("ID товара (Enter — завершить): ").strip()
        if not raw_id:
            break
        if not raw_id.isdigit():
            print("ID должен быть числом.")
            continue
        product = next((p for p in products if p["id"] == int(raw_id)), None)
        if product is None:
            print("Товар с таким ID не найден.")
            continue
        raw_qty = input("Количество: ").strip()
        if not raw_qty.isdigit() or int(raw_qty) <= 0:
            print("Количество должно быть положительным числом.")
            continue
        qty = int(raw_qty)
        if qty > product["quantity"]:
            print(f"На складе только {product['quantity']} шт.")
            continue
        cart.append({"id": product["id"], "name": product["name"],
                     "price": product["price"], "quantity": qty})
        product["quantity"] -= qty
        print(f"Добавлено: {product['name']} x {qty}")

    if not cart:
        print("Корзина пуста, заказ не оформлен.")
        return None

    order = {"items": cart, "total": cart_total(cart)}
    orders = load_orders()
    orders.append(order)
    save_orders(orders)
    print(f"Заказ оформлен. Сумма: {order['total']} руб. Сохранено в orders.json")
    return order


# --- Меню ---
def ask_number(prompt):
    raw = input(prompt).strip()
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        print("Это не число, параметр пропущен.")
        return None


def main():
    while True:
        print("\n=== СпортТовары ===")
        print("1. Показать все товары")
        print("2. Товары с низким остатком")
        print("3. Поиск товаров")
        print("4. Аналитика по категориям")
        print("5. Оформить заказ")
        print("0. Выход")
        choice = input("Выберите пункт: ").strip()

        if choice == "1":
            show_products(PRODUCTS)
        elif choice == "2":
            low = get_low_stock(PRODUCTS)
            if low:
                show_products(low)
            else:
                print("Нет товаров с низким остатком")
        elif choice == "3":
            query = input("Название или бренд: ")
            category = input("Категория (Enter — любая): ").strip() or None
            min_price = ask_number("Мин. цена (Enter — без ограничения): ")
            max_price = ask_number("Макс. цена (Enter — без ограничения): ")
            show_products(search_advanced(PRODUCTS, query, category, min_price, max_price))
        elif choice == "4":
            for category, count in count_by_category(PRODUCTS).items():
                print(f"{category}: {count}")
        elif choice == "5":
            show_products(PRODUCTS)
            create_order(PRODUCTS)
        elif choice == "0":
            print("До свидания!")
            break
        else:
            print("Неверный пункт меню.")


if __name__ == "__main__":
    main()