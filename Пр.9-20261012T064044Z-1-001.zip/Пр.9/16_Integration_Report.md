# Отчёт об интеграции модулей

## Какие модули были выделены
- src/catalog.py - работа с каталогом: find_product, get_low_stock, search_advanced, count_by_category, avg_price
- src/cart.py - корзина: add_to_cart, remove_from_cart, update_quantity, cart_total, total_sum
- src/orders.py - заказы: create_order, print_order, save_orders, load_orders
- src/analytics.py - аналитика: total_revenue, best_selling_product, average_order_total
- src/storage.py - JSON-хранилище товаров: load_products, save_products
- main.py - точка входа с меню, build.py - скрипт сборки
- Старый монолитный файл shop.py удалён, его функции перенесены в модули.

## Какие импорты используются
- src/cart.py: from src.catalog import find_product
- src/orders.py: from src.cart import cart_total, from src.catalog import find_product
- main.py: импортирует функции из catalog, cart, orders, analytics и storage
- src/catalog.py, src/analytics.py, src/storage.py - внутренних импортов нет (нижний уровень)
- Используется восходящая интеграция: catalog, затем cart, затем orders, затем analytics.

## Какие интеграционные тесты написаны
- tests/test_integration.py (6 тестов):
  - test_full_cycle - полный цикл: товар в корзину, заказ, сохранение в JSON, загрузка, сверка суммы, аналитика
  - test_print_order_after_load - вывод заказа после загрузки из файла
  - test_stock_changes_after_order - остаток на складе уменьшается после заказа
  - test_order_too_many_items_fails - нельзя оформить заказ на товар сверх остатка
  - test_products_file_is_valid - файл data/products.json существует и содержит все нужные поля
  - test_save_and_load_products - сохранение и загрузка товаров через storage
- Всего в проекте 53 теста, все проходят.

## Какие ошибки были найдены и исправлены
- Намеренная ошибка: ключ "name" заменён на "product" в src/cart.py. Интеграционные тесты упали с KeyError: 'name', ошибка исправлена (подробности в docs/15_Integration_Errors.md).
- В тестах задания использовался параметр size, но в проекте у товаров нет размеров, поэтому функции корзины работают без него.

## Как работает скрипт сборки
- build.py последовательно выполняет 5 шагов: проверка версии Python (3.10+), установка зависимостей (если есть requirements.txt), проверка файла data/products.json, запуск всех тестов (unittest discover), запуск приложения main.py.
- Если любой шаг не проходит, скрипт выводит сообщение и завершается с кодом 1.
- Ключ --no-run выполняет все проверки и тесты, но не запускает приложение.

## Структура проекта
SportShop/
- src/ (__init__.py, catalog.py, cart.py, orders.py, analytics.py, storage.py)
- tests/ (__init__.py, test_catalog.py, test_cart.py, test_orders.py, test_analytics.py, test_integration.py)
- docs/
- data/ (products.json)
- main.py
- build.py